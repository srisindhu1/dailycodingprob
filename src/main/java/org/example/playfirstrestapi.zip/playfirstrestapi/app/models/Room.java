package models;

import java.util.*;

public class Room{
    int id;
    String type;
    double price;
    double rating;

    public Room(int id, String type, double price, double rating) {
        this.id = id;
        this.type = type;
        this.price = price;
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public double getPrice() {
        return price;
    }
    public double getRating() {
        return rating;
    }

    public String toString() {
        return "id : "+id+" type : "+type+" price : "+price+" rating : "+rating;
    }
}