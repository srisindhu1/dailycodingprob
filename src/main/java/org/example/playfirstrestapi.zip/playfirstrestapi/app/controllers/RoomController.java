package controllers;
import play.mvc.*;


import javax.inject.Inject;
import models.Room;
import models.Server;

import java.awt.*;
import java.util.*;

public class RoomController extends Controller {

    Server server;
    @Inject
    public RoomController() {
        server = new Server();
    }

    public Result  create(int id, String type, double price, double rating) {

            return ok(server.addroom(id, type, price, rating));

    }
    public Result retrieve(int id) {

            return ok(server.getRoom(id));

    }

    public Result update(int id, String type, double price, double rating) {

            boolean isUpdated = server.updateroom(id, type, price, rating);

            return isUpdated == true ? ok("room updated successfully\n" + server.getRoom(id)) :
                    ok("No room with id " + id);

    }

    public Result delete(int id) {
        boolean isDeleted = server.deleteroom(id);

        return isDeleted == true ? ok("room deleted successfully") : ok("No room with id "+id);
    }
}

