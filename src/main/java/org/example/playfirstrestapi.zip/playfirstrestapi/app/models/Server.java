package models;

import java.util.*;

public class Server {
    Map<Integer, Room> rooms = new HashMap<>();

    public String  addroom(int id, String type, double price, double rating) {
        rooms.put(id, new Room(id, type, price, rating));
        return "room added successfully\n"+getRoom(id);
    }

    public String getRoom(int id) {
        if(rooms.get(id) != null) {
            Room room = rooms.get(id);
            return "room\n\tId : "+room.getId()+"\n\ttypee : "+room.getType()+"\n\tPrice : "+room.getPrice()
                    +"\n\tRating : "+room.getRating();
        }
        return "No room with id "+id;
    }

    public boolean updateroom(int id, String type, double price, double rating) {
        if(rooms.get(id) != null) {
            rooms.put(id, new Room(id, type, price, rating));
            return true;
        }
        return false;
    }

    public boolean deleteroom(int id) {
        if(rooms.get(id) != null) {
            rooms.remove(id);
            return true;
        }
        return false;
    }
}